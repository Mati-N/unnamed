(window.webpackJsonp=window.webpackJsonp||[]).push([[12],{"./src/components/SVG/Comments.js":
/*!****************************************!*\
  !*** ./src/components/SVG/Comments.js ***!
  \****************************************/
/*! exports provided: default */function(o,e){throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nError: ENOENT: no such file or directory, open '/mnt/c/Users/Mimi/Desktop/Projects/feel/project/frontend/src/components/SVG/Comments.js'")}}]);
//# sourceMappingURL=12.main.js.map