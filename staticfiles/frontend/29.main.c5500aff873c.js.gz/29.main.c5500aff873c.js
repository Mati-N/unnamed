(window.webpackJsonp=window.webpackJsonp||[]).push([[29],{"./src/components/layout/Alert.js":
/*!****************************************!*\
  !*** ./src/components/layout/Alert.js ***!
  \****************************************/
/*! exports provided: default */function(e,t,n){"use strict";n.r(t);var o=n(/*! react */"./node_modules/react/index.js"),r=n.n(o),s=n(/*! ../../context/alert/AlertContext */"./src/context/alert/AlertContext.js"),a=n(/*! @material-ui/lab */"./node_modules/@material-ui/lab/esm/index.js");t.default=function(){var e=Object(o.useContext)(s.default),t=e.alert_info,n=e.removeAlert;return t&&r.a.createElement(a.Alert,{onClose:n,severity:t.alert_type},t&&t.msg)}}}]);
//# sourceMappingURL=29.main.js.map