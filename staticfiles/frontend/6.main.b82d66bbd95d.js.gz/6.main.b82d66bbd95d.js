(window.webpackJsonp=window.webpackJsonp||[]).push([[6],{"./src/components/SVG/Edit.svg":
/*!*************************************!*\
  !*** ./src/components/SVG/Edit.svg ***!
  \*************************************/
/*! exports provided: default */function(e,t,n){"use strict";n.r(t);var o=n(/*! react */"./node_modules/react/index.js");function r(){return(r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e}).apply(this,arguments)}var s=o.createElement("path",{d:"M0 0h24v24H0z",stroke:"none"}),a=o.createElement("path",{d:"M9 7H6a2 2 0 00-2 2v9a2 2 0 002 2h9a2 2 0 002-2v-3"}),c=o.createElement("path",{d:"M9 15h3l8.5-8.5a1.5 1.5 0 00-3-3L9 12v3M16 5l3 3"});t.default=function(e){return o.createElement("svg",r({className:"Edit_svg__icon Edit_svg__icon-tabler Edit_svg__icon-tabler-edit",width:44,height:44,viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"#2c3e50",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"},e),s,a,c)}},"./src/components/SVG/Logout.svg":
/*!***************************************!*\
  !*** ./src/components/SVG/Logout.svg ***!
  \***************************************/
/*! exports provided: default */function(e,t,n){"use strict";n.r(t);var o=n(/*! react */"./node_modules/react/index.js");function r(){return(r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e}).apply(this,arguments)}var s=o.createElement("path",{d:"M0 0h24v24H0z",stroke:"none"}),a=o.createElement("path",{d:"M14 8V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2h7a2 2 0 002-2v-2"}),c=o.createElement("path",{d:"M7 12h14l-3-3m0 6l3-3"});t.default=function(e){return o.createElement("svg",r({width:45,height:45,strokeWidth:2,stroke:"#607D8B",fill:"none",strokeLinecap:"round",strokeLinejoin:"round"},e),s,a,c)}},"./src/components/layout/AccountInfo.js":
/*!**********************************************!*\
  !*** ./src/components/layout/AccountInfo.js ***!
  \**********************************************/
/*! exports provided: default */function(e,t,n){"use strict";n.r(t);n(/*! react */"./node_modules/react/index.js"),n(/*! react-router-dom */"./node_modules/react-router-dom/esm/react-router-dom.js"),n(/*! ../SVG/Logout.svg */"./src/components/SVG/Logout.svg"),n(/*! ../SVG/Edit.svg */"./src/components/SVG/Edit.svg");t.default=UserInfo}}]);
//# sourceMappingURL=6.main.js.map