(window.webpackJsonp=window.webpackJsonp||[]).push([[1],{"./src/components/post/PostItem.js":
/*!*****************************************!*\
  !*** ./src/components/post/PostItem.js ***!
  \*****************************************/
/*! exports provided: default */function(n,o,s){"use strict";s.r(o);s(/*! react */"./node_modules/react/index.js");o.default=function(){return"WHY ISNT IT NOT WORKING"}}}]);
//# sourceMappingURL=1.main.js.map