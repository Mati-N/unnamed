(window.webpackJsonp=window.webpackJsonp||[]).push([[15],{"./src/components/layout/Footer.js":
/*!*****************************************!*\
  !*** ./src/components/layout/Footer.js ***!
  \*****************************************/
/*! exports provided: default */function(e,t,o){"use strict";o.r(t);var n=o(/*! react */"./node_modules/react/index.js"),r=o.n(n),u=(o(/*! react-router-dom */"./node_modules/react-router-dom/esm/react-router-dom.js"),o(/*! ../../context/auth/AuthContext */"./src/context/auth/AuthContext.js"));t.default=function(){var e=Object(n.useContext)(u.default),t=e.isAuthenticated;return e.loading||null==t?"":r.a.createElement("footer",null,"Made by me")}}}]);
//# sourceMappingURL=15.main.js.map