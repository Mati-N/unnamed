(window.webpackJsonp=window.webpackJsonp||[]).push([[19],{"./src/components/pages/NotFound.js":
/*!******************************************!*\
  !*** ./src/components/pages/NotFound.js ***!
  \******************************************/
/*! exports provided: default */function(e,n,o){"use strict";o.r(n);var t=o(/*! react */"./node_modules/react/index.js"),a=o.n(t);n.default=function(){return a.a.createElement(a.a.Fragment,null,a.a.createElement("h2",null,"404 Not Found"),a.a.createElement("p",null,"The page you are looking for does not exists."))}}}]);
//# sourceMappingURL=19.main.js.map