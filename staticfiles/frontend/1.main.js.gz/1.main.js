(window.webpackJsonp=window.webpackJsonp||[]).push([[1],{"./src/components/pages/Offline.js":
/*!*****************************************!*\
  !*** ./src/components/pages/Offline.js ***!
  \*****************************************/
/*! exports provided: default */function(e,n,a){"use strict";a.r(n);var l=a(/*! react */"./node_modules/react/index.js"),t=a.n(l);n.default=function(){return t.a.createElement(t.a.Fragment,null,t.a.createElement("h1",null," It seems like you are offline ")," ",t.a.createElement("small",null," Try refreshing ")," ")}}}]);
//# sourceMappingURL=1.main.js.map