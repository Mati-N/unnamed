(window.webpackJsonp=window.webpackJsonp||[]).push([[2],{"./src/components/pages/Offline.js":
/*!*****************************************!*\
  !*** ./src/components/pages/Offline.js ***!
  \*****************************************/
/*! exports provided: default */function(e,n,l){"use strict";l.r(n);var s=l(/*! react */"./node_modules/react/index.js"),t=l.n(s);n.default=function(){return t.a.createElement("div",null,t.a.createElement("h1",null,"It seems like you are offline"),t.a.createElement("small",null,"Try refreshing"))}}}]);
//# sourceMappingURL=2.main.js.map