(window.webpackJsonp=window.webpackJsonp||[]).push([[27],{"./src/components/layout/Footer.js":
/*!*****************************************!*\
  !*** ./src/components/layout/Footer.js ***!
  \*****************************************/
/*! exports provided: default */function(e,t,n){"use strict";n.r(t);var a=n(/*! react */"./node_modules/react/index.js"),o=n.n(a),l=n(/*! recoil */"./node_modules/recoil/es/recoil.js"),s=n(/*! ../../atoms */"./src/atoms.js");t.default=function(){return null===Object(l.useRecoilValue)(s.authAtom).isAuthenticated?"":o.a.createElement("footer",null,o.a.createElement("span",null,"A Social Media App."),o.a.createElement("span",null,"UNNAMED."),o.a.createElement("a",{href:"https://github.com/Mati-N/unnamed"},"GITHUB."))}}}]);
//# sourceMappingURL=27.main.js.map