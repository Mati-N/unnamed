(window.webpackJsonp=window.webpackJsonp||[]).push([[20],{"./src/components/pages/Notifications.js":
/*!***********************************************!*\
  !*** ./src/components/pages/Notifications.js ***!
  \***********************************************/
/*! exports provided: default */function(e,o,n){"use strict";n.r(o);var s=n(/*! react */"./node_modules/react/index.js");n(/*! ../../Queries */"./src/Queries.js"),n(/*! @apollo/client */"./node_modules/@apollo/client/index.js"),n(/*! react-waypoint */"./node_modules/react-waypoint/es/index.js"),n(/*! react-spinners-kit */"./node_modules/react-spinners-kit/lib/index.js");Object(s.lazy)((function(){return Promise.resolve().then(n.bind(null,/*! react-router-dom */"./node_modules/react-router-dom/esm/react-router-dom.js"))})).Link;o.default=Notifications}}]);
//# sourceMappingURL=20.main.js.map