(window.webpackJsonp=window.webpackJsonp||[]).push([[2],{"./src/components/post/Posts.js":
/*!**************************************!*\
  !*** ./src/components/post/Posts.js ***!
  \**************************************/
/*! exports provided: default */function(e,n,t){"use strict";t.r(n);var r=t(/*! react */"./node_modules/react/index.js"),s=t.n(r);function o(){return(o=Object.assign||function(e){for(var n=1;n<arguments.length;n++){var t=arguments[n];for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])}return e}).apply(this,arguments)}var a=Object(r.lazy)((function(){return t.e(/*! import() */3).then(t.bind(null,/*! ./PostItem */"./src/components/post/PostItem.js"))}));n.default=function(e){var n=e.posts,t=e.self,r=e.username,u=e.id;return s.a.createElement("div",null,n.map((function(e){var n=e.node;return s.a.createElement(a,o({key:n.id},n,{user_id:t?u:n.user.id,username:t?r:n.user.username,show_comment:!1}))})))}}}]);
//# sourceMappingURL=2.main.js.map