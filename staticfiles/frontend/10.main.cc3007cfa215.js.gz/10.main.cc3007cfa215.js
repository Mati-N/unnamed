(window.webpackJsonp=window.webpackJsonp||[]).push([[10],{"./src/components/SVG/Heart.js":
/*!*************************************!*\
  !*** ./src/components/SVG/Heart.js ***!
  \*************************************/
/*! exports provided: default */function(o,e){throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nError: ENOENT: no such file or directory, open '/mnt/c/Users/Mimi/Desktop/Projects/feel/project/frontend/src/components/SVG/Heart.js'")}}]);
//# sourceMappingURL=10.main.js.map