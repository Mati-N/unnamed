(window.webpackJsonp=window.webpackJsonp||[]).push([[16],{"./src/components/layout/Footer.js":
/*!*****************************************!*\
  !*** ./src/components/layout/Footer.js ***!
  \*****************************************/
/*! exports provided: default */function(e,t,n){"use strict";n.r(t);var a=n(/*! react */"./node_modules/react/index.js"),o=n.n(a),r=(n(/*! react-router-dom */"./node_modules/react-router-dom/esm/react-router-dom.js"),n(/*! ../../context/auth/AuthContext */"./src/context/auth/AuthContext.js"));t.default=function(){var e=Object(a.useContext)(r.default),t=e.isAuthenticated;return e.loading||null==t?"":o.a.createElement("footer",null,o.a.createElement("span",null,"A Social Media App."),o.a.createElement("span",null,"UNNAMED."),o.a.createElement("a",{href:"https://github.com/Mati-N/unnamed"},"GITHUB."))}}}]);
//# sourceMappingURL=16.main.js.map